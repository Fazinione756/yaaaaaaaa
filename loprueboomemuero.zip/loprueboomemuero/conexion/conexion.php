<?php
$servidor="localhost";
$usuario="root";
$contraseña="";
$bd="crud_ajax";

$conexion=mysqli_connect($servidor, $usuario, $contraseña, $bd);

if ($conexion){
    echo "Conexion Exitosa";
} else {
    echo "Error de Conexion";
}

?>